enum DetailsLevel {
  None,
  Overview,
  FullDiff,
}

export default DetailsLevel;
